package com.tax.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
