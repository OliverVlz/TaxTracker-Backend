package com.tax.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxTrackerApplication.class, args);
	}

}
